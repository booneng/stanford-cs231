from gnureadline import *
from gnureadline import __doc__
